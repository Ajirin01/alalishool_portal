<?php for($i = 1; $i <= 5; $i++): ?>
    <div class="card card-default">
        <div class="card-header">
        <h3 class="card-title"><?php echo e(strtoupper($noun[0]).substr($noun, 1, strlen($noun))); ?> <?php echo e($i); ?></h3>

        <div class="card-tools">
            <button type="button" id="collapse-<?php echo e($noun); ?>-area<?php echo e($i); ?>" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
            </button>
        </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="row">
                <div class="card-body">
                    <input type="text" name="" id="text<?php echo e($i); ?>add<?php echo e($noun); ?>" class="form-control" placeholder="please enter <?php echo e($noun); ?>">
                </div>
            </div>
            <!-- /.row -->
        </div>
    </div>
<?php endfor; ?>

<button class="btn btn-primary" onclick="add(<?php echo e(json_encode($noun)); ?>)">Submit</button>

<script>
    $(document).ready(function(){
        for(let i= 1; i <= 5; i++){
            $("#collapse-"+ <?php echo e(Js::from($noun)); ?> +"-area"+i).click()
        }
        
    })

    var data = []

    function add(noun){
        let key = <?php echo e(Js::from($key)); ?>

        console.log(key)
        loopTextFieldsToData(noun, key)
        let component_url = "/components/general-table-body-row-3-col"

        addRecords(noun, component_url, data, key)
    }
</script><?php /**PATH C:\wamp64\www\Al-Ali CBT\resources\views/components/general/noun-add.blade.php ENDPATH**/ ?>