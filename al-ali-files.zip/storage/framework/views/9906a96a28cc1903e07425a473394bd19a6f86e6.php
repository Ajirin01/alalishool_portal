<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Comp</title>
</head>
<body id="body">
    
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginalfe522fe912a6e44bad2d3e0bb4f14c959939964f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Question\Test::class, ['message' => $student->name] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('question.test'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Question\Test::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe522fe912a6e44bad2d3e0bb4f14c959939964f)): ?>
<?php $component = $__componentOriginalfe522fe912a6e44bad2d3e0bb4f14c959939964f; ?>
<?php unset($__componentOriginalfe522fe912a6e44bad2d3e0bb4f14c959939964f); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    

    <script>
        fetch("/comp-api?message=done!").then(re => re.text()).then(res => {
            console.log(res)

            document.getElementById('body').innerHTML += res
        })
    </script>
</body>
</html><?php /**PATH C:\wamp64\www\Al-Ali CBT\resources\views/comp.blade.php ENDPATH**/ ?>