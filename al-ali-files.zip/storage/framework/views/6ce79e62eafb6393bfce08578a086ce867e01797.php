

<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-tabs">
                <div class="card-header p-0 pt-1">
                    <ul class="nav nav-tabs" id="custom-tabs-five-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="custom-tabs-five-overlay-dark-tab" data-toggle="pill" href="#custom-tabs-five-overlay-dark" role="tab" aria-controls="custom-tabs-five-overlay-dark" aria-selected="true">Exam Papers</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="custom-tabs-five-overlay-dark-tab2" data-toggle="pill" href="#custom-tabs-five-overlay-dark2" role="tab" aria-controls="custom-tabs-five-overlay-dark2">Add Exam Papers</a>
                        </li>
                    </ul>
                </div>

                <div class="card-body">
                    <div class="tab-content" id="custom-tabs-five-tabContent">
                        <div class="tab-pane fade show active" id="custom-tabs-five-overlay-dark" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-dark-tab">
                            <div class="overlay-wrapper">
                                <div style="display: none; text-align: center" class="overlay dark" id="ajax-loader"><i style="position: fixed; margin-top: 20vh" class="fas fa-3x fa-sync-alt fa-spin"></i></div>

                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-name">Switch between tabs to manage exams</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <table id="example1" class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Exam Papers</th>
                                                    <th>Duration</th>
                                                    <th>Start Time</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="exam-paper-table-body">
                                                <?php $__currentLoopData = $exam_papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i =>  $exam_paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $sn =  $i + 1 ;
                                                        // echo $sn;
                                                    ?>
                                                    <tr id="exam_paper<?php echo e($exam_paper->id); ?>row">
                                                        <td><?php echo e($i + 1); ?></td>
                                                        
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.exam_paper.exam-paper-area','data' => ['id' => $exam_paper->id,'name' => $exam_paper->name,'duration' => $exam_paper->duration,'startTime' => $exam_paper->start_time,'status' => $exam_paper->status,'instruction' => $exam_paper->instruction]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('exam_paper.exam-paper-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->id),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->name),'duration' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->duration),'startTime' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->start_time),'status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->status),'instruction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->instruction)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Exam Papers</th>
                                                    <th>Duration</th>
                                                    <th>Start Time</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                                <!-- /.card -->
                            </div>
                        </div>

                        
                        <div class="tab-pane fade show" id="custom-tabs-five-overlay-dark2" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-dark-tab2">
                            <div class="overlay-wrapper">
                                
                                <div style="display: none; text-align: center" class="overlay dark" id="ajax-loader2"><i style="position: fixed; margin-top: 20vh" class="fas fa-3x fa-sync-alt fa-spin"></i></div>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.exam_paper.exam-paper-add','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('exam_paper.exam-paper-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                            
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>


    <script>
        const options = <?php echo e(Js::from($options)); ?>;

        var name = ""
        var duration = ""
        var start_time = ""
        var instruction = ""
        var status = ""

        var data = {}

        function handleNameChange(){
            name = event.target.value
        }

        function handleDurationChange(){
            duration = event.target.value
        }

        function handleStartTimeChange(){
            start_time = event.target.value
        }

        function handleStatusChange(){
            status = event.target.value
        }

        function handleInstructionsChange(){
            instruction = event.target.value
        }

        function addExamPaper(noun){
            const options = <?php echo e(Js::from($options)); ?>

            data = {
                name,
                duration,
                instruction,
                start_time,
                status,
                classes_id: options.classes_id,
                subject_id: options.subject_id,
                exam_id: options.exam_id
            }
            
            const oneOrMoreFieldEmpty = ($("#name-add").val() == "" || $("#duration-add").val() == "" || $("#start-time-add").val()  == "" || $("#status-add").val() == "")

            console.clear()
            console.log(data)

            if(!oneOrMoreFieldEmpty){
                $('#custom-tabs-five-normal2').css('opacity', 0)
                document.getElementById('ajax-loader2').style.display = 'block'

                fetch("/api/exam_papers/", {
                    method: "POST",
                    headers: {
                        'Content-type': 'application/json'
                    },
                    body: JSON.stringify(data)
                }).
                then(response => response.json()).
                then(res => {
                    let params = ""
                    let componentUrl = ""

                    componentUrl = "/components/exam-paper-table-body-row"
                    params = "?id=" + res.data.id + "& noun= " + noun

                    fetch(componentUrl + params, {
                        method: "GET",
                        headers: {
                            'Content-type': 'application/json'
                        }
                    }).then(comRes => comRes.text()).then(component => {
                        document.getElementById(noun+"-table-body").innerHTML += component
                        // console.log(component)

                        successAlert("<h5>"+ res.message +"</h5>")
                        
                        $("#name-add").val('')
                        $("#duration-add").val('')
                        $("#start-time-add").val('')
                        $("#status-add").val('')


                        $('#custom-tabs-five-normal2').css('opacity', 1)
                        document.getElementById('ajax-loader2').style.display = 'none'
                    })
                })
                    
                data = []
            }else{
                errorAlert("<h5>Can not submit!</h5> <p>Please Fill all fields</p>")
            }
        }

        function updateExamPaper(id){
            name = $("#name-edit"+id).val()
            duration = $("#duration-edit"+id).val()
            instruction =  $("#instruction-edit"+id).val()
            start_time = $("#start-time-edit"+id).val()
            status = $("#status-edit"+id).val()

            var data = {
                name,
                duration,
                instruction,
                start_time,
                status,
                classes_id: options.classes_id,
                subject_id: options.subject_id,
                exam_id: options.exam_id
            }

            // console.log(data)

            $('.modal').css('opacity', 0)
            document.getElementById('ajax-loader').style.display = 'block'

            fetch("/api/exam_papers/" + id, {
                method: "PUT",
                headers: {
                    'Content-type': 'application/json'
                },
                body: JSON.stringify(data)
            }).
            then(response => response.json()).
            then(res => {
                document.getElementById("examPaperTitle" + id + "output").innerHTML =   res.data.name
                document.getElementById("examPaperDuration" + id + "output").innerHTML =   res.data.duration
                document.getElementById("examPaperStartTime" + id + "output").innerHTML =   res.data.start_time
                document.getElementById("examPaperStatus" + id + "output").innerHTML =   res.data.status

                document.getElementById("closeupdate" + id + "exam-paper").click() 
                // console.log(res.message)
                successAlert("<h5>"+ res.message +"</h5>")
                document.getElementById('ajax-loader').style.display = 'none'
                $('.modal').css('opacity', 1)
            })
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Al-Ali CBT\resources\views/admin/exam_papers/index.blade.php ENDPATH**/ ?>