

<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-tabs">
                <div class="card-header p-0 pt-1">
                    <ul class="nav nav-tabs" id="custom-tabs-five-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="custom-tabs-five-overlay-dark-tab" data-toggle="pill" href="#custom-tabs-five-overlay-dark" role="tab" aria-controls="custom-tabs-five-overlay-dark" aria-selected="true">Students (Class => <?php echo e($class->name); ?>)</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="custom-tabs-five-overlay-dark-tab2" data-toggle="pill" href="#custom-tabs-five-overlay-dark2" role="tab" aria-controls="custom-tabs-five-overlay-dark2">Add Students</a>
                        </li>
                    </ul>
                </div>

                <div class="card-body">
                    <div class="tab-content" id="custom-tabs-five-tabContent">
                        <div class="tab-pane fade show active" id="custom-tabs-five-overlay-dark" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-dark-tab">
                            <div class="overlay-wrapper">
                                <div style="display: none; text-align: center" class="overlay dark" id="ajax-loader"><i style="position: fixed; margin-top: 20vh" class="fas fa-3x fa-sync-alt fa-spin"></i></div>
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">Switch between tabs to manage exams</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <table id="example1" class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Name</th>
                                                    <th>Admission Number</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="student-table-body">
                                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i =>  $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $sn =  $i + 1 ;
                                                    ?>
                                                    <?php if($student->user !== null): ?>
                                                        <tr id="student<?php echo e($student->id); ?>row">
                                                            <td><?php echo e($i + 1); ?></td>
                                                            
                                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student.student-area','data' => ['id' => $student->id,'name' => $student->name,'phone' => $student->user->phone,'email' => $student->user->email]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('student.student-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($student->id),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($student->name),'phone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($student->user->phone),'email' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($student->user->email)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Name</th>
                                                    <th>Admission Number</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                                <!-- /.card -->
                            </div>
                        </div>

                        
                        <div class="tab-pane fade show" id="custom-tabs-five-overlay-dark2" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-dark-tab2">
                            <div class="overlay-wrapper">
                                
                                <div style="display: none; text-align: center" class="overlay dark" id="ajax-loader2"><i style="position: fixed; margin-top: 20vh" class="fas fa-3x fa-sync-alt fa-spin"></i></div>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student.student-add','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('student.student-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                            
                        </div>
                    </div>
                    <!-- /.card -->
                    <input type="hidden" id="options" value="<?php echo e(json_encode($options)); ?>">
                </div>
            </div>
        </div>
    </div>


    <script>
        var name = ""
        var phone = ""
        var email = ""
        var password = ""
        var role = "student"
        var options = JSON.parse($("#options").val())
        var data = {}

        // console.log(options.classes_id)

        function handleNameChange(){
            name = event.target.value
        }

        function handlePhoneChange(){
            phone = event.target.value
        }

        function handleEmailChange(){
            email = event.target.value
        }

        function handlePasswordChange(){
            password = event.target.value
        }

        function addStudent(noun){
            console.clear()
            console.log(options)
            data = [{
                name,
                phone,
                email,
                password: email,
                classes_id: options.classes_id,
                role
            }]
            
            const oneOrMoreFieldEmpty = ($("#name-add").val() == "" || $("#email-add").val()  == "")

            console.log(data)

            if(!oneOrMoreFieldEmpty){
                $('#custom-tabs-five-normal2').css('opacity', 0)
                document.getElementById('ajax-loader2').style.display = 'block'

                fetch("<?php echo e(URL::to('')); ?>"+"/api/user/register", {
                    method: "POST",
                    headers: {
                        'Content-type': 'application/json'
                    },
                    body: JSON.stringify(data)
                }).
                then(user_response => user_response.json()).
                then(user_res => {
                    console.log(user_res.data[0])
                    fetch("<?php echo e(URL::to('')); ?>"+"/api/"+noun+"s", {
                        method: "POST",
                        headers: {
                            'Content-type': 'application/json'
                        },
                        body: JSON.stringify({
                            user_id: user_res.data[0].id,
                            classes_id: options.classes_id,
                            name: user_res.data[0].name
                            
                        })
                    }).
                    then(student_response => student_response.json()).
                    then(student_res => {
                        console.log(student_res)
                        let params = ""
                        let componentUrl = ""

                        componentUrl = "<?php echo e(URL::to('')); ?>"+"/components/student-table-body-row"
                        params = "?id=" + student_res.data.id + "& noun= " + noun

                        fetch(componentUrl + params, {
                            method: "GET",
                            headers: {
                                'Content-type': 'application/json'
                            }
                        }).then(comRes => comRes.text()).then(component => {
                            document.getElementById(noun+"-table-body").innerHTML += component
                            // console.log(component)

                            successAlert("<h5>"+ student_res.message +"</h5>")
                            
                            $("#name-add").val('')
                            $("#phone-add").val('')
                            $("#email-add").val('')


                            $('#custom-tabs-five-normal2').css('opacity', 1)
                            document.getElementById('ajax-loader2').style.display = 'none'
                        })
                    })
                        
                    data = []
                })

            }else{
                errorAlert("<h5>Can not submit!</h5> <p>Please Fill all fields</p>")
            }
        }

        function updateStudent(id){
            name = $("#name-edit"+id).val()
            phone = $("#phone-edit"+id).val()
            email = $("#email-edit"+id).val()
            password = $("#password-edit"+id).val()

            var data = {
                name,
                email,
                phone
            }

            if(password !== "" ){
                data['password'] = password
            }


            $('.modal').css('opacity', 0)
            document.getElementById('ajax-loader').style.display = 'block'

            fetch("<?php echo e(URL::to('')); ?>"+"/api/students/" + id, {
                method: "PUT",
                headers: {
                    'Content-type': 'application/json'
                },
                body: JSON.stringify(data)
            }).
            then(student_response => student_response.json()).
            then(student_res => {
                console.log(student_res)
                fetch("<?php echo e(URL::to('')); ?>"+"/api/user/update/" + student_res.data.user.id, {
                    method: "PUT",
                    headers: {
                        'Content-type': 'application/json'
                    },
                    body: JSON.stringify(data)
                }).
                then(response => response.json()).
                then(res => {
                    document.getElementById("studentName" + id + "output").innerHTML =   res.data.name

                    document.getElementById("closeupdate" + id + "student").click() 
                    // console.log(res.message)
                    successAlert("<h5>"+ res.message +"</h5>")
                    document.getElementById('ajax-loader').style.display = 'none'
                    $('.modal').css('opacity', 1)
                })
            })

            
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Al-Ali_CBT2\resources\views/admin/student/index.blade.php ENDPATH**/ ?>