

<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-tabs">
                <div class="card-header p-0 pt-1">
                    <ul class="nav nav-tabs" id="custom-tabs-five-tab" role="tablist">
                        <li class="nav-item" style="width: 100%;">
                            <?php if(count($results) > 0): ?>
                                <div style="float: left; padding-left: 20px">
                                    <h3>Results</h3>
                                    <span><b>Exam: </b></span> <span class="text-default"><?php echo e($results[0]->exam->title); ?></span> <br>
                                    <span><b>Exam Paper: </b></span> <span class="text-default"><?php echo e($results[0]->exam_paper->name); ?></span> <br>
                                </div>
                                <div style="float: right; padding-right: 20px">
                                    <span><b>Class: </b></span> <span class="text-default"><?php echo e($results[0]->classes->name); ?></span> <br>
                                    <span><b>Subject: </b></span> <span class="text-default"><?php echo e($results[0]->subject->name); ?></span> <br>
                                    <span><b>Year: </b></span> <span class="text-default"><?php echo e($results[0]->year->year); ?></span> <br>
                                    <span><b>Term: </b></span> <span class="text-default"><?php echo e($results[0]->term->name); ?></span> <br>
                                </div>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>

                <div class="card-body">
                    <div class="tab-content" id="custom-tabs-five-tabContent">
                        <div class="tab-pane fade show active" id="custom-tabs-five-overlay-dark" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-dark-tab">
                            <div class="overlay-wrapper">
                                <div style="display: none; text-align: center" class="overlay dark" id="ajax-loader"><i style="position: fixed; margin-top: 20vh" class="fas fa-3x fa-sync-alt fa-spin"></i></div>

                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">Students result by Year, Term, Class, Subject, Exam and Exam Paper</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <table id="example1" class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Student</th>
                                                    <th>Over</th>
                                                    <?php if(Auth::user()->role == "admin"): ?>
                                                        <th>Score</th>
                                                        <th>Actions</th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody id="result-table-body">
                                                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i =>  $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr id="result<?php echo e($result->id); ?>row">
                                                        <td><?php echo e($i + 1); ?></td>
                                                        <td>
                                                            <?php echo e($result->student->name); ?>

                                                        </td>
                                                        <td><?php echo e($result->over); ?></td>
                                                        
                                                        <?php if(Auth::user()->role == "admin"): ?>
                                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.general.noun-area','data' => ['id' => $result->id,'name' => $result->score,'noun' => 'result']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('general.noun-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($result->id),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($result->score),'noun' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('result')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Student</th>
                                                    <th>Over</th>
                                                    <?php if(Auth::user()->role == "admin"): ?>
                                                        <th>Score</th>
                                                        <th>Actions</th>
                                                    <?php endif; ?>
                                                    
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                                <!-- /.card -->
                            </div>
                        </div>

                        
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>

    <script>
        function update(id, noun){
            let input = "text" + id + noun

            let data = {
                score: $("#"+input).val()
            }

            updateData(data, id, noun)
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Al-Ali CBT\resources\views/admin/results/index.blade.php ENDPATH**/ ?>