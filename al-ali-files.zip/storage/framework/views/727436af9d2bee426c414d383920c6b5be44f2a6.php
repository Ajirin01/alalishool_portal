
<script>
    if(sessionStorage.getItem('questions') !== undefined){
        sessionStorage.setItem('questions', JSON.stringify(<?php echo e(Js::from($questions)); ?>))
    }
    sessionStorage.setItem('exam_paper', JSON.stringify(<?php echo e(Js::from($exam_paper)); ?>))

    window.location = "<?php echo e(URL::to('/student/exam')); ?>"
</script><?php /**PATH C:\wamp64\www\Al-Ali_CBT2\resources\views/student/set-exam.blade.php ENDPATH**/ ?>