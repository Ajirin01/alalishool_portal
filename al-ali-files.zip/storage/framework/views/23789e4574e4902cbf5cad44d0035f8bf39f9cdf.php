
<div>
    I have not failed. I've just found 10,000 ways that won't work. - Thomas Edison
    <?php
        echo "<h1>fine</h1>";
    ?>

    <h2><?php echo e($message); ?></h2>
</div>
<?php /**PATH C:\wamp64\www\Al-Ali CBT\resources\views/components/question/test.blade.php ENDPATH**/ ?>