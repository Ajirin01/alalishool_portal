<li id="teacher_classe<?php echo e($id); ?>li">
    <span id="teacher_classes<?php echo e($id); ?>output"><?php echo e($name); ?></span>

    
    <div class="modal fade" id="modal-danger<?php echo e($id); ?>classes">
        <div class="modal-dialog">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">Delete Warning</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>Are you sure you want to unassign this class?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal" id="closedelete<?php echo e($id); ?>teacher_classe">Close</button>
              <button type="button" class="btn btn-outline-light" onclick="deleteRecord(<?php echo e($id); ?>, 'teacher_classe', 'li')">Yes</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
    <span data-toggle="modal" data-target="#modal-danger<?php echo e($id); ?>classes"><i class="fa fa-times"></i></span>
    <!-- /.modal -->
    
</li><?php /**PATH C:\wamp64\www\Al-Ali_CBT2\resources\views/components/teacher/teacher-classes-area.blade.php ENDPATH**/ ?>