

<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-tabs">
                <div class="card-header p-0 pt-1">
                    <ul class="nav nav-tabs" id="custom-tabs-five-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="custom-tabs-five-overlay-dark-tab" data-toggle="pill" href="#custom-tabs-five-overlay-dark" role="tab" aria-controls="custom-tabs-five-overlay-dark" aria-selected="true">Teachers</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="custom-tabs-five-overlay-dark-tab2" data-toggle="pill" href="#custom-tabs-five-overlay-dark2" role="tab" aria-controls="custom-tabs-five-overlay-dark2">Add Teachers</a>
                        </li>
                    </ul>
                </div>

                <div class="card-body">
                    <div class="tab-content" id="custom-tabs-five-tabContent">
                        <div class="tab-pane fade show active" id="custom-tabs-five-overlay-dark" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-dark-tab">
                            <div class="overlay-wrapper">
                                <div style="display: none; text-align: center" class="overlay dark" id="ajax-loader"><i style="position: fixed; margin-top: 20vh" class="fas fa-3x fa-sync-alt fa-spin"></i></div>

                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">Switch between tabs to manage exams</h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <table id="example1" class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Teachers</th>
                                                    <th>Classes</th>
                                                    <th>Subjects</th>
                                                </tr>
                                            </thead>
                                            <tbody id="teacher-table-body">
                                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i =>  $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $sn =  $i + 1 ;
                                                    ?>
                                                    <tr id="teacher<?php echo e($teacher->id); ?>row">
                                                        <td><?php echo e($i + 1); ?></td>
                                                        
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.teacher.teacher-area','data' => ['id' => $teacher->id,'name' => $teacher->name,'phone' => $teacher->user->phone,'email' => $teacher->user->email]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teacher->id),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teacher->name),'phone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teacher->user->phone),'email' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teacher->user->email)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                        <td>
                                                            <ul id="teacher_classes<?php echo e($teacher->id); ?>area">
                                                                <?php $__currentLoopData = $teacher->teacher_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if (isset($component)) { $__componentOriginal02d0e96c3080f81d524147fcc5899ff0aec14100 = $component; } ?>
<?php $component = App\View\Components\Teacher\TeacherClassesArea::resolve(['id' => $class->id,'name' => $class->classes_name] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-classes-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Teacher\TeacherClassesArea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02d0e96c3080f81d524147fcc5899ff0aec14100)): ?>
<?php $component = $__componentOriginal02d0e96c3080f81d524147fcc5899ff0aec14100; ?>
<?php unset($__componentOriginal02d0e96c3080f81d524147fcc5899ff0aec14100); ?>
<?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                            <?php if (isset($component)) { $__componentOriginal2843bd589c18c6a77aa8ad868e8158f1321378af = $component; } ?>
<?php $component = App\View\Components\Teacher\TeacherClassesAdd::resolve(['id' => $teacher->id,'classes' => $classes,'teacher' => $teacher] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-classes-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Teacher\TeacherClassesAdd::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2843bd589c18c6a77aa8ad868e8158f1321378af)): ?>
<?php $component = $__componentOriginal2843bd589c18c6a77aa8ad868e8158f1321378af; ?>
<?php unset($__componentOriginal2843bd589c18c6a77aa8ad868e8158f1321378af); ?>
<?php endif; ?>
                                                        </td>

                                                        <td>
                                                            <ul id="teacher_subject<?php echo e($teacher->id); ?>area">
                                                                <?php $__currentLoopData = $teacher->teacher_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if (isset($component)) { $__componentOriginald5f8abfb78066facfba2d666b3337bb649ea7989 = $component; } ?>
<?php $component = App\View\Components\Teacher\TeacherSubjectsArea::resolve(['id' => $subject->id,'name' => $subject->subject_name] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-subjects-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Teacher\TeacherSubjectsArea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5f8abfb78066facfba2d666b3337bb649ea7989)): ?>
<?php $component = $__componentOriginald5f8abfb78066facfba2d666b3337bb649ea7989; ?>
<?php unset($__componentOriginald5f8abfb78066facfba2d666b3337bb649ea7989); ?>
<?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                            <?php if (isset($component)) { $__componentOriginal6e3649a8deb8aca60b086a8606922b530daccfd9 = $component; } ?>
<?php $component = App\View\Components\Teacher\TeacherSubjectsAdd::resolve(['id' => $teacher->id,'subjects' => $subjects,'teacher' => $teacher] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-subjects-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Teacher\TeacherSubjectsAdd::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e3649a8deb8aca60b086a8606922b530daccfd9)): ?>
<?php $component = $__componentOriginal6e3649a8deb8aca60b086a8606922b530daccfd9; ?>
<?php unset($__componentOriginal6e3649a8deb8aca60b086a8606922b530daccfd9); ?>
<?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Teachers</th>
                                                    <th>Classes</th>
                                                    <th>Subjects</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                                <!-- /.card -->
                            </div>
                        </div>

                        
                        <div class="tab-pane fade show" id="custom-tabs-five-overlay-dark2" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-dark-tab2">
                            <div class="overlay-wrapper">
                                
                                <div style="display: none; text-align: center" class="overlay dark" id="ajax-loader2"><i style="position: fixed; margin-top: 20vh" class="fas fa-3x fa-sync-alt fa-spin"></i></div>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.teacher.teacher-add','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                            
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>


    <script>
        var name = ""
        var phone = ""
        var email = ""
        var password = ""
        var role = "teacher"

        var data = {}

        function handleNameChange(){
            name = event.target.value
        }

        function handlePhoneChange(){
            phone = event.target.value
        }

        function handleEmailChange(){
            email = event.target.value
        }

        function handlePasswordChange(){
            password = event.target.value
        }

        function addTeacher(noun){
            data = [{
                name,
                phone,
                email,
                password: email,
                role
            }]
            
            const oneOrMoreFieldEmpty = ($("#name-add").val() == "" || $("#phone-add").val() == "" || $("#email-add").val()  == "")

            console.clear()
            console.log(data)

            if(!oneOrMoreFieldEmpty){
                $('#custom-tabs-five-normal2').css('opacity', 0)
                document.getElementById('ajax-loader2').style.display = 'block'

                // fetch("../api/user/register/", {
                fetch("<?php echo e(URL::to('api/user/register')); ?>", {
                    method: "POST",
                    headers: {
                        'Content-type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify(data)
                }).
                then(user_response => user_response.json()).
                then(user_res => {
                    console.log(user_res.data[0])
                    fetch("<?php echo e(URL::to('')); ?>"+"/api/"+noun+"s", {
                        method: "POST",
                        headers: {
                            'Content-type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify({
                            user_id: user_res.data[0].id,
                            name: user_res.data[0].name
                        })
                    }).
                    then(teacher_response => teacher_response.json()).
                    then(teacher_res => {
                        console.log(teacher_res)
                        let params = ""
                        let componentUrl = ""

                        componentUrl = "<?php echo e(URL::to('')); ?>"+"/components/teacher-table-body-row"
                        params = "?id=" + teacher_res.data.id + "& noun= " + noun

                        fetch(componentUrl + params, {
                            method: "GET",
                            headers: {
                                'Content-type': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        }).then(comRes => comRes.text()).then(component => {
                            document.getElementById(noun+"-table-body").innerHTML += component
                            // console.log(component)

                            successAlert("<h5>"+ teacher_res.message +"</h5>")
                            
                            $("#name-add").val('')
                            $("#phone-add").val('')
                            $("#email-add").val('')


                            $('#custom-tabs-five-normal2').css('opacity', 1)
                            document.getElementById('ajax-loader2').style.display = 'none'
                        })
                    })
                        
                    data = []
                })

            }else{
                errorAlert("<h5>Can not submit!</h5> <p>Please Fill all fields</p>")
            }
        }

        function updateTeacher(id){
            name = $("#name-edit"+id).val()
            phone = $("#phone-edit"+id).val()
            email = $("#email-edit"+id).val()
            password = $("#password-edit"+id).val()

            var data = {
                name,
                email,
                phone
            }

            if(password !== "" ){
                data['password'] = password
            }


            $('.modal').css('opacity', 0)
            document.getElementById('ajax-loader').style.display = 'block'

            fetch("<?php echo e(URL::to('')); ?>"+"/api/teachers/" + id, {
                method: "PUT",
                headers: {
                    'Content-type': 'application/json'
                },
                body: JSON.stringify(data)
            }).
            then(teacher_response => teacher_response.json()).
            then(teacher_res => {
                console.log(teacher_res)
                fetch("<?php echo e(URL::to('')); ?>"+"/api/user/update/" + teacher_res.data.user.id, {
                    method: "PUT",
                    headers: {
                        'Content-type': 'application/json'
                    },
                    body: JSON.stringify(data)
                }).
                then(response => response.json()).
                then(res => {
                    document.getElementById("teacherName" + id + "output").innerHTML =   res.data.name

                    document.getElementById("closeupdate" + id + "teacher").click() 
                    // console.log(res.message)
                    successAlert("<h5>"+ res.message +"</h5>")
                    document.getElementById('ajax-loader').style.display = 'none'
                    $('.modal').css('opacity', 1)
                })
            })

            
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Al-Ali_CBT2\resources\views/admin/teacher/index.blade.php ENDPATH**/ ?>