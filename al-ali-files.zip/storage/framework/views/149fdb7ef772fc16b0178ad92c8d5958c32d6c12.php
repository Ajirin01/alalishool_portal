
<?php $__env->startSection('header-content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Welcome Back!</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    
                    <span>
                        <?php echo e(date("Y-m-d")); ?> 
                    </span>
                     <span id="clock"></span>
                </ol>
            </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Main content -->
    <div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h5 class="m-0">Welcome <?php echo e(Auth::user()->name); ?></h5>
                    </div>
                    
                    <?php if($message === 'exam and no result'): ?>
                        <div class="card-body" id="exam-paper-exist">
                            <h6 class="card-title">Exam is ready</h6>

                            <p class="card-text">Please read instructions before attempting exams questions</p> 

                            <h4>Instructions</h4>
                            <p id="instruction"></p>

                            
                            <form action="<?php echo e(route('set-exam')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="classes_id" id="classes_id">
                                <input type="hidden" name="exam_paper_id" id="exam_paper_id">
                                <input type="submit" class="btn btn-primary" value="Start exam">
                            </form>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($message === 'no exam and result'): ?>
                        <div class="card-body" id="exam-paper-not-exist">
                            <h6 class="card-title">No exam questions found!</h6>

                            <p class="card-text">Please there is no exam for you at the moment</p>
                            <a href="<?php echo e(route('student-logout')); ?>" class="btn btn-primary">Logout</a>
                        </div>
                    <?php endif; ?>

                
                    
                    <?php if($message === 'exam and result'): ?>
                        <div class="card-body" id="result-exist">
                            <h6 class="card-title">Exam already taken!</h6>

                            <p class="card-text">Please note that you have already taken this exam</p>
                            <a href="<?php echo e(route('student-logout')); ?>" class="btn btn-primary">Logout</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    <script>
        var span = document.getElementById('clock');

        function time() {
            var d = new Date();
            var s = d.getSeconds();
            var m = d.getMinutes();
            var h = d.getHours();
            span.textContent =  "_____" + ("0" + h).substr(-2) + ":" + ("0" + m).substr(-2) + ":" + ("0" + s).substr(-2);
        }

        setInterval(time, 1000);
    </script>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.exam_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Al-Ali_CBT2\resources\views/student/welcome.blade.php ENDPATH**/ ?>