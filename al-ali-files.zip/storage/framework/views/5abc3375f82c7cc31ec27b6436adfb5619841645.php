<?php for($i = 1; $i <= 5; $i++): ?>
    <div class="card card-default">
        <div class="card-header">
        <h3 class="card-title">Year <?php echo e($i); ?></h3>

        <div class="card-tools">
            <button type="button" id="collapse-year-area<?php echo e($i); ?>" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
            </button>
        </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="row">
                <div class="card-body">
                    <input type="text" name="" id="text<?php echo e($i); ?>addyear" class="form-control" placeholder="e.g. 2020/2021">
                </div>
            </div>
            <!-- /.row -->
        </div>
    </div>
<?php endfor; ?>

<button class="btn btn-primary" onclick="addYears('year')">Submit</button>

<script>
    $(document).ready(function(){
        for(let i= 1; i <= 5; i++){
            $("#collapse-year-area"+i).click()
        }
        
    })
    
    var data = []

    function addYears(noun){
        loopTextFieldsToData(noun)
        let component_url = "/components/general-table-body-row-3-col"

        addRecords(noun, component_url, data)
    }
</script><?php /**PATH C:\wamp64\www\Al-Ali CBT\resources\views/components/year/year-add.blade.php ENDPATH**/ ?>