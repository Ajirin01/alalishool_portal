<tr id="question<?php echo e($question->id); ?>row">
    <td class="text-danger">New</td>
    <td>
        
        <?php if (isset($component)) { $__componentOriginala6453cfe8f414500748f027e740e46f876e48951 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Question\QuestionArea::class, ['questionId' => $question->id,'question' => $question->question] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('question.question-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Question\QuestionArea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6453cfe8f414500748f027e740e46f876e48951)): ?>
<?php $component = $__componentOriginala6453cfe8f414500748f027e740e46f876e48951; ?>
<?php unset($__componentOriginala6453cfe8f414500748f027e740e46f876e48951); ?>
<?php endif; ?>

        <ul id="answer-list<?php echo e($question->id); ?>">
            <?php $__currentLoopData = $question->question_answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j =>  $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if (isset($component)) { $__componentOriginal6e539708e82d1ef3e8e74b0d3045289820c6ef1d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Question\QuestionAnswerArea::class, ['answerId' => json_decode($answer)->id,'answer' => json_decode($answer)->answer,'correct' => json_decode($answer)->correct] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('question.question-answer-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Question\QuestionAnswerArea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e539708e82d1ef3e8e74b0d3045289820c6ef1d)): ?>
<?php $component = $__componentOriginal6e539708e82d1ef3e8e74b0d3045289820c6ef1d; ?>
<?php unset($__componentOriginal6e539708e82d1ef3e8e74b0d3045289820c6ef1d); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        
        <?php if (isset($component)) { $__componentOriginalb4e6b2c3eba2b86683a835532af7cfc455f4c59c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Question\QuestionAnswerAdd::class, ['questionId' => $question->id] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('question.question-answer-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Question\QuestionAnswerAdd::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb4e6b2c3eba2b86683a835532af7cfc455f4c59c)): ?>
<?php $component = $__componentOriginalb4e6b2c3eba2b86683a835532af7cfc455f4c59c; ?>
<?php unset($__componentOriginalb4e6b2c3eba2b86683a835532af7cfc455f4c59c); ?>
<?php endif; ?>
        
    </td>
</tr><?php /**PATH C:\wamp64\www\Al-Ali CBT\resources\views/components/question/table-body-row.blade.php ENDPATH**/ ?>