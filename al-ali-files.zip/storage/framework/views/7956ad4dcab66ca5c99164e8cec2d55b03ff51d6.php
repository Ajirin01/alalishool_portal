<tr id="exam_paper<?php echo e($exam_paper->id); ?>row">
    <td class="text-danger">New</td>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.exam_paper.exam-paper-area','data' => ['id' => $exam_paper->id,'name' => $exam_paper->name,'duration' => $exam_paper->duration,'startTime' => $exam_paper->start_time,'status' => $exam_paper->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('exam_paper.exam-paper-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->id),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->name),'duration' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->duration),'startTime' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->start_time),'status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam_paper->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</tr><?php /**PATH C:\wamp64\www\Al-Ali_CBT2\resources\views/components/exam_paper/table-body-row.blade.php ENDPATH**/ ?>