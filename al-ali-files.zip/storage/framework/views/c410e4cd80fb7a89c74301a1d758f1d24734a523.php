<td>
    <span id="teacherName<?php echo e($id); ?>output" style="float: left">
        <?php echo e($name); ?>

    </span>
    <div style="float: right">
        
        <div class="modal fade" id="modal-xl<?php echo e($id); ?>teacher-view">
            <div class="modal-dialog modal-xl<?php echo e($id); ?>teacher">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-name">View teacher</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card card-outline card-info">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" name="" class="form-control" value="<?php echo e($name); ?>" disabled>
                                        </div>

                                        <div class="form-group">
                                            <label for="name">Email</label>
                                            <input type="email" name="" class="form-control" value="<?php echo e($email); ?>" disabled>
                                        </div>

                                        <div class="form-group">
                                            <label for="name">Phone Number</label>
                                            <input type="tel" name="" class="form-control" value="<?php echo e($phone); ?>" disabled>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.col-->
                        </div>
                        <!-- ./row -->
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-primary form-control" data-dismiss="modal" id="closeview<?php echo e($id); ?>teacher">Close</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <span data-toggle="modal" data-target="#modal-xl<?php echo e($id); ?>teacher-view"><i class="fa fa-eye" ></i></span>


        
        <div class="modal fade" id="modal-xl<?php echo e($id); ?>teacher">
            <div class="modal-dialog modal-xl<?php echo e($id); ?>teacher">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-name">Edit teacher</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card card-outline card-info">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" name="" id="name-edit<?php echo e($id); ?>" class="form-control" placeholder="enter teacher name" value="<?php echo e($name); ?>" onchange="handleNameChange()">
                                        </div>

                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="email" name="" id="email-edit<?php echo e($id); ?>" class="form-control" placeholder="enter teacher email" value="<?php echo e($email); ?>" onchange="handleEmailChange()">
                                        </div>

                                        <div class="form-group">
                                            <label for="phone">Phone Number</label>
                                            <input type="tel" name="" id="phone-edit<?php echo e($id); ?>" class="form-control" placeholder="enter teacher phone number" value="<?php echo e($phone); ?>" onchange="handlePhoneChange()">
                                        </div>

                                        <div class="form-group">
                                            <label for="password">Password  <small>N.B. leave empty to retain old password</small> </label>
                                            <input type="text" name="" id="password-edit<?php echo e($id); ?>" class="form-control" onchange="handlePasswordChange()">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.col-->
                        </div>
                        <!-- ./row -->
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal" id="closeupdate<?php echo e($id); ?>teacher">Close</button>
                        <button type="button" class="btn btn-primary" onclick="updateTeacher(<?php echo e($id); ?>, 'teacher')">Save changes</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <span data-toggle="modal" data-target="#modal-xl<?php echo e($id); ?>teacher"><i class="fa fa-edit" ></i></span>
    
        
        <div class="modal fade" id="modal-danger<?php echo e($id); ?>teacher">
            <div class="modal-dialog">
                <div class="modal-content bg-danger">
                <div class="modal-header">
                    <h4 class="modal-name">Delete Warning</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this record?</p>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-outline-light" data-dismiss="modal" id="closedelete<?php echo e($id); ?>teacher">Close</button>
                    <button type="button" class="btn btn-outline-light" onclick="deleteRecord(<?php echo e($id); ?>, 'teacher', 'row')">Yes</button>
                </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
        <span data-toggle="modal" data-target="#modal-danger<?php echo e($id); ?>teacher"><i class="fa fa-trash"></i></span>
        <!-- /.modal -->
    
        
    
    </div>
</td>






<?php /**PATH C:\wamp64\www\Al-Ali _CBT\resources\views/components/teacher/teacher-area.blade.php ENDPATH**/ ?>