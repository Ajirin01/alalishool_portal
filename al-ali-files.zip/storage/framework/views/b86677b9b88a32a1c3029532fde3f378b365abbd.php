<tr id="exam<?php echo e($exam->id); ?>row">
    <td class="text-danger">New</td>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.exam.exam-area','data' => ['id' => $exam->id,'title' => $exam->title,'description' => $exam->descripton,'startDate' => $exam->start_date,'endDate' => $exam->end_date,'status' => $exam->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('exam.exam-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam->id),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam->title),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam->descripton),'startDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam->start_date),'endDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam->end_date),'status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($exam->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</tr><?php /**PATH C:\wamp64\www\Al-Ali_CBT2\resources\views/components/exam/table-body-row.blade.php ENDPATH**/ ?>