

<?php $__env->startSection('admin-content'); ?>
    <h1 class="text-center">Dashboard</h1>
    <h2>Welcome to Al-Ali International School CBT management system!</h2>
    <p>Please use the navigations on the left manage your options</p>
    <br>
    <br>
    <br>
    <marquee behavior="" direction="left">Dashboard reports coming soon!!!</marquee>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Al-Ali _CBT\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>