<tr id="teacher<?php echo e($teacher->id); ?>row">
    <td class="text-danger">New</td>
    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.teacher.teacher-area','data' => ['id' => $teacher->id,'name' => $teacher->name,'phone' => $teacher->user->phone,'email' => $teacher->user->email]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teacher->id),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teacher->name),'phone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teacher->user->phone),'email' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teacher->user->email)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <td>
        <ul id="teacher_classes<?php echo e($teacher->id); ?>area">
            <?php $__currentLoopData = $teacher->teacher_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal02d0e96c3080f81d524147fcc5899ff0aec14100 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Teacher\TeacherClassesArea::class, ['id' => $class->id,'name' => $class->classes_name] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-classes-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Teacher\TeacherClassesArea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02d0e96c3080f81d524147fcc5899ff0aec14100)): ?>
<?php $component = $__componentOriginal02d0e96c3080f81d524147fcc5899ff0aec14100; ?>
<?php unset($__componentOriginal02d0e96c3080f81d524147fcc5899ff0aec14100); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php if (isset($component)) { $__componentOriginal2843bd589c18c6a77aa8ad868e8158f1321378af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Teacher\TeacherClassesAdd::class, ['id' => $teacher->id,'classes' => $classes,'teacher' => $teacher] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-classes-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Teacher\TeacherClassesAdd::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2843bd589c18c6a77aa8ad868e8158f1321378af)): ?>
<?php $component = $__componentOriginal2843bd589c18c6a77aa8ad868e8158f1321378af; ?>
<?php unset($__componentOriginal2843bd589c18c6a77aa8ad868e8158f1321378af); ?>
<?php endif; ?>
    </td>

    <td>
        <ul id="teacher_subject<?php echo e($teacher->id); ?>area">
            <?php $__currentLoopData = $teacher->teacher_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginald5f8abfb78066facfba2d666b3337bb649ea7989 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Teacher\TeacherSubjectsArea::class, ['id' => $subject->id,'name' => $subject->subject_name] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-subjects-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Teacher\TeacherSubjectsArea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5f8abfb78066facfba2d666b3337bb649ea7989)): ?>
<?php $component = $__componentOriginald5f8abfb78066facfba2d666b3337bb649ea7989; ?>
<?php unset($__componentOriginald5f8abfb78066facfba2d666b3337bb649ea7989); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php if (isset($component)) { $__componentOriginal6e3649a8deb8aca60b086a8606922b530daccfd9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Teacher\TeacherSubjectsAdd::class, ['id' => $teacher->id,'subjects' => $subjects,'teacher' => $teacher] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher.teacher-subjects-add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Teacher\TeacherSubjectsAdd::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e3649a8deb8aca60b086a8606922b530daccfd9)): ?>
<?php $component = $__componentOriginal6e3649a8deb8aca60b086a8606922b530daccfd9; ?>
<?php unset($__componentOriginal6e3649a8deb8aca60b086a8606922b530daccfd9); ?>
<?php endif; ?>
    </td>
</tr><?php /**PATH C:\wamp64\www\Al-Ali CBT\resources\views/components/teacher/table-body-row.blade.php ENDPATH**/ ?>