
<div>
    I have not failed. I've just found 10,000 ways that won't work. - Thomas Edison
    @php
        echo "<h1>fine</h1>";
    @endphp

    <h2>{{ $message }}</h2>
</div>
