@extends('layouts.admin_layout')

@section('admin-content')
    <h1 class="text-center">Dashboard</h1>
    <h2>Welcome to Al-Ali International School CBT management system!</h2>
    <p>Please use the navigations on the left manage your options</p>
    <br>
    <br>
    <br>
    <marquee behavior="" direction="left">Dashboard reports coming soon!!!</marquee>
@endsection