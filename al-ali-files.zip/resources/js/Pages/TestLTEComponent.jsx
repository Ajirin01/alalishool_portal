import React from 'react';
import GuestLayout from '@/Layouts/GuestLayout';
import LTEButton from '@/Components/AdminLTE/LTEButton';

export default function TestLTEComponent(props) {
    return (
        <div>
            <LTEButton />
        </div>
    );
}
